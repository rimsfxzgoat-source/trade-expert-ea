package com.tradeexpert.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.webkit.JavascriptInterface;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

/** What the web page reports to the app: bot ON/OFF and new signals. */
public class TeBridge {

    static final String CHANNEL = "te_signals";
    private final Context ctx;
    private int nextId = 2000;

    public TeBridge(Context c) {
        ctx = c.getApplicationContext();
        NotificationChannel ch = new NotificationChannel(
                CHANNEL, "Signals", NotificationManager.IMPORTANCE_HIGH);
        ch.enableVibration(true);
        ctx.getSystemService(NotificationManager.class).createNotificationChannel(ch);
    }

    /** The bot switch: the bubble over other apps follows it. */
    @JavascriptInterface
    public void botState(boolean on) {
        BubbleService.setBotOn(ctx, on);
    }

    /** A new signal: show it as a notification. */
    @JavascriptInterface
    public void show(String title, String body) {
        try {
            PendingIntent pi = PendingIntent.getActivity(ctx, 0,
                    new Intent(ctx, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            Notification n = new NotificationCompat.Builder(ctx, CHANNEL)
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentTitle(title)
                    .setContentText(body)
                    .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                    .setAutoCancel(true)
                    .setContentIntent(pi)
                    .build();
            NotificationManagerCompat nm = NotificationManagerCompat.from(ctx);
            if (nm.areNotificationsEnabled()) {
                nm.notify(nextId++, n);
            }
        } catch (SecurityException ignored) {
        }
    }
}
